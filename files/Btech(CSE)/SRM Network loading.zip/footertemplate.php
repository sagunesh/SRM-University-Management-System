<?php
//This script is created by Sagunesh Grover
?>
<div id="footer_container">
	<br />
		<center>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="about.html"style="text-decoration: none"class="blue">About</a>&nbsp;&nbsp;<a href="contact.html"style="text-decoration: none"class="blue">Contact</a>&nbsp;&nbsp;<a href="faq.html"style="text-decoration: none"class="blue">Faqs</a>&nbsp;&nbsp;<a href="terms.html"style="text-decoration: none"class="blue">Terms</a>&nbsp;&nbsp;<a href="privacy.html"style="text-decoration: none"class="blue">Privacy</a>
		</center>
		<center> SRM University Haryana Productions</center>
        <center>Srmuhums.in &#169 2014</center>
</div>