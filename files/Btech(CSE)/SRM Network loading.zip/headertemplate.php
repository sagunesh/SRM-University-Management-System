<?php
/*
*
*
------------------------------------This Script is Created By Sagunesh Grover-----------------------------
*
*
*/
?>
<img src="images/Logo.png" style="position:absolute;left:22%"  height="100%"  >
<div  id="header_container">

	<center><h2 style="font-family:arial;"><a href="index.php" style="text-decoration:none;color:#1C8DFF;">SRM UH University Management System</a></h2><?php echo $logOptions; ?></center>

</div>
