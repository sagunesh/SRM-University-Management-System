<!------MessageBody Starts Here--->
<!--------Inner Message Table-------->
<!-----Message Tabs Start Here-------->
<ul class="tabs">
    <li><a href="#view1">Inbox</a></li>
    <li><a href="#view2">Compose</a></li>
    <li><a href="#view3">Sentbox</a></li>
</ul>
<!-------------Inbox Tab Starts Here-------------------------->
<div class="tabcontents">
    <div id="view1">
<table width="100%" style="background-color:white;" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="732" valign="top">
  <h1 style="margin-left:24px;"><center>[ Your Inbox ]</center></h2>
<!-- START THE PM FORM AND DISPLAY LIST -->
<form name="myform" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">
        <table width="94%" border="0" align="center" cellpadding="4">
          <tr>
            <td width="3%" align="right" valign="bottom"><img src="images/crookedArrow.png" width="16" height="17" alt="Click Here to Delete" /></td>
            <td width="97%" valign="top"><input type="submit" name="deleteBtn" id="deleteBtn" class="myButton" value="Delete" />
              <span id="jsbox" style="display:none"></span>
            </td></tr>
          </tr>
      </table>
        <table width="96%" border="0" align="center" cellpadding="4"  style="border: #999 1px solid;">
          <tr>
            <td width="4%" valign="top">
            <input name="toggleAll" id="toggleAll" type="checkbox" onclick="toggleChecks(document.myform.cb)" />
            </td>
            <td width="20%" valign="top"><B>From</B></td>
            <td width="58%" valign="top"><span class="style2"><b>Subject</b></span></td>
            <td width="18%" valign="top"><B>Date</B></td>
          </tr>
        </table> 
<?php
///////////End take away///////////////////////
// SQL to gather their entire PM list
$sql = mysql_query("SELECT * FROM private_messages WHERE to_id='$my_id' AND recipientDelete='0' ORDER BY id DESC LIMIT 100");

while($row = mysql_fetch_array($sql)){ 

    $date = strftime("%b %d, %Y",strtotime($row['time_sent']));
    if($row['opened'] == "0"){
		    $textWeight = 'msgDefault';
    } else {
			$textWeight = 'msgRead';
    }
    $fr_id = $row['from_id'];    
    // SQL - Collect username for sender inside loop
    $ret = mysql_query("SELECT id, username FROM myMembers WHERE id='$fr_id' LIMIT 1");
    while($raw = mysql_fetch_array($ret)){ $Sid = $raw['id']; $Sname = $raw['username']; }

?>
        <table width="96%" border="0" align="center" cellpadding="4">
          <tr>
            <td width="4%" valign="top">
            <input type="checkbox" name="cb<?php echo $row['id']; ?>" id="cb" value="<?php echo $row['id']; ?>" />
            </td>
            <td width="20%" valign="top"><a href="mainlogin.php?id=<?php echo $Sid; ?>" style="text-decoration:none;" class="blue1"><?php echo $Sname; ?></a></td>
            <td width="58%" valign="top">
              <span class="toggle" style="padding:3px;">
              <a class="<?php echo $textWeight; ?>" id="subj_line_<?php echo $row['id']; ?>" style="cursor:pointer;" onclick="markAsRead(<?php echo $row['id']; ?>)"><?php echo stripslashes($row['subject']); ?></a>
              </span>
              <div class="hiddenDiv"> <br />
                <?php echo stripslashes(wordwrap(nl2br($row['message']), 54, "\n", true)); ?>
                <br /><br /><br />
              </div>
             
  </td>
            <td width="18%" valign="top"><span style="font-size:12px;"><b><?php echo $date; ?></b></span></td>
          </tr>
        </table>
<hr style="margin-left:20px; margin-right:20px;" />
<?php
}// Close Main while loop
?>
<BR /><BR /><BR /><BR /><BR />
</form>
<!-- END THE PM FORM AND DISPLAY LIST -->
<!-- Start Hidden Container the holds the Reply Form -->            
<div id="replyBox" style="display:none; width:680px; height:264px; background-color: #005900; background-repeat:repeat; border: #333 1px solid; top:51px; position:fixed; margin:auto; z-index:50; padding:20px; color:#FFF;">
<div align="right"><a href="javascript:toggleReplyBox('close')"><font color="#00CCFF"><strong>CLOSE</strong></font></a></div>
<h2>Replying to <span style="color:#ABE3FE;" id="recipientShow"></span></h2>
Subject: <strong><span style="color:#ABE3FE;" id="subjectShow"></span></strong> <br>
<form action="javascript:processReply();" name="replyForm" id="replyForm" method="post">
<textarea id="pmTextArea" rows="8" style="width:98%;"></textarea><br />
<input type="hidden" id="pmSubject" />
<input type="hidden" id="pm_rec_id" />
<input type="hidden" id="pm_rec_name" />
<input type="hidden" id="pm_sender_id" />
<input type="hidden" id="pm_sender_name" />
<input type="hidden" id="pmWipit" />
<br />
<input name="replyBtn" type="button" onclick="javascript:processReply()" /> &nbsp;&nbsp;&nbsp; <span id="pmFormProcessGif"><img src="images/loading.gif" width="28" height="10" alt="Loading" /></span>
<div id="PMStatus" style="color:#F00; font-size:14px; font-weight:700;">&nbsp;</div>
</form>
</div>
<!-- End Hidden Container the holds the Reply Form -->     
<!-- Start PM Reply Final Message box showing user message status when needed -->    
 <div id="PMFinal" style="display:none; width:652px; background-color:#005900; border:#666 1px solid; top:51px; position:fixed; margin:auto; z-index:50; padding:40px; color:#FFF; font-size:16px;"></div>
 <!-- End PM Reply Final Message box showing user message status when needed --> 
</td></tr></table>
</div>
<!--------------Inbox Ends Here------------------>
<!---------------Compose Message Starts Here------>
<div id="view2">
        <center><h1>[ Compose Message ]</h1></center>
    </div>
 <!----------Compose Message Ends Here----------->
 <!-------Sent Box Starts Here----------------->
    <div id="view3">
      <table width="920" style="background-color:white;" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="732" valign="top">
  <center><h1 style="margin-left:24px;">[ Messages You Sent ]</h1></center>
<!-- START THE PM FORM AND DISPLAY LIST -->
<form name="myform" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">
        <table width="94%" border="0" align="center" cellpadding="4">
          <tr>
            <td width="3%" align="right" valign="bottom"><img src="images/crookedArrow.png" width="16" height="17" alt="Click Here to Delete" /></td>
            <td width="97%" valign="top"><input type="submit" name="deleteBtn" id="deleteBtn"  class="myButton" value="Delete"  />
              <span id="jsbox" style="display:none"></span>
            </td>
          </tr>
      </table>
        <table width="96%" border="0" align="center" cellpadding="4" style="  border: #999 1px solid;">
          <tr>
            <td width="4%" valign="top">
            <input name="toggleAll" id="toggleAll" type="checkbox" onclick="toggleChecks(document.myform.cb)" />
            </td>
            <td width="20%" valign="top">To</td>
            <td width="58%" valign="top"><span class="style2">Subject</span></td>
            <td width="18%" valign="top">Date</td>
          </tr>
        </table> 
<?php
///////////End take away///////////////////////
// SQL to gather their entire PM list
$sql = mysql_query("SELECT * FROM private_messages WHERE from_id='$my_id' AND senderDelete='0' ORDER BY id DESC LIMIT 100");

while($row = mysql_fetch_array($sql)){ 

    $date = strftime("%b %d, %Y",strtotime($row['time_sent']));
    $to_id = $row['to_id'];    
    // SQL - Collect username for Recipient 
    $ret = mysql_query("SELECT id, username FROM myMembers WHERE id='$to_id' LIMIT 1");
    while($raw = mysql_fetch_array($ret)){ $Rid = $raw['id']; $Rname = $raw['username']; }

?>
        <table width="96%" border="0" align="center" cellpadding="4">
          <tr>
            <td width="4%" valign="top">
            <input type="checkbox" name="cb<?php echo $row['id']; ?>" id="cb" value="<?php echo $row['id']; ?>" />
            </td>
            <td width="20%" valign="top"><a href="mainlogin.php?id=<?php echo $Rid; ?>" style="text-decoration:none;" class="blue1"><?php echo $Rname; ?></a></td>
            <td width="58%" valign="top">
              <span class="toggle" style="padding:3px;">
              <a class="msgDefault" id="subj_line_<?php echo $row['id']; ?>" style="cursor:pointer;"><?php echo stripslashes($row['subject']); ?></a>
              </span>
              <div class="hiddenDiv"> <br />
                <?php echo stripslashes(wordwrap(nl2br($row['message']), 54, "\n", true)); ?>
                <br />
              </div>
           </td>
            <td width="18%" valign="top"><span style="font-size:12px;"><B><?php echo $date; ?></B></span></td>
          </tr>
        </table>
<hr style="margin-left:20px; margin-right:20px;" />
<?php
}// Close Main while loop
?>
<BR /><BR /><BR /><BR /><BR /><br /><br />
</form></td></tr></table>
    </div>
 <!--------------Sent Box Ends Here---------------->
</div>

<!------Message Body Ends Here----->