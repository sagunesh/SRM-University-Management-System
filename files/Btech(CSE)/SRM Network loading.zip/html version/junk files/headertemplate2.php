<?php
/*
*
*
------------------------------------This Script is Created By Sagunesh Grover-----------------------------
*
*
*/
?>
<div>
<center><h1 style="font-family:arial;font-size:35px;"><font color="#1C8DFF">[Coursemash]</font></h1>&nbsp;&nbsp;&nbsp;<a href="home.php"style="text-decoration: none"class="white">Home</a>&nbsp;&nbsp;&nbsp;<a href="terms.php"style="text-decoration: none"class="white">terms</a>&nbsp;&nbsp;&nbsp;<a href="about.php"style="text-decoration: none"class="white">about</a><br /></center>
</div>