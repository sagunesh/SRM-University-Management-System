<?php
/*
----------This Script is created by Sagunesh Grover----------
*/
?>

<table cellspacing="0"  align="center">
  <tr><td><h1>[ Welcome to SRM UH UMS ]</h1></td></tr></table>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Srmuhums.in is an online directory that connect students through each other and teachers <br><br>
&nbsp;&nbsp;&nbsp;&nbsp&nbsp;We have opened Srmuhums.in for popular consumption at <b>SRM University Haryana.</b><br><br>
&nbsp;&nbsp;&nbsp;&nbsp&nbsp;Your  Srmuhums.in is limited to your own  university.<br><br>

<ul type="square">
You can use Srmuhums.in to:
&nbsp;&nbsp;&nbsp;&nbsp&nbsp;<li>Search for people at your college
&nbsp;&nbsp;&nbsp;&nbsp&nbsp;<li>Find out who is in your class
&nbsp;&nbsp;&nbsp;&nbsp&nbsp;<li>Look up  friends' friends
&nbsp;&nbsp;&nbsp;&nbsp&nbsp;<li>See a visualization of your Syllabus and Courses
&nbsp;&nbsp;&nbsp;&nbsp&nbsp;<li>Ask doubts from teachers and learn courses in a better way
</ul>
&nbsp&nbsp;&nbsp;&nbsp;<center>To get started, click <a href="login.php"style="text-decoration: none"class="blue">here</a> to login.</center><br><br />